"""BeadSov core: image -> fuse-bead (Perler/Hama/Artkal style) pattern -> PDF. No network, no storage."""
import io, math
from collections import deque
import numpy as np
from PIL import Image, ImageOps
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

# Approximate generic bead colors (name r g b). Brands differ slightly: always check against your beads.
RAW = """White 255 255 255|Cream 244 232 196|Pastel Yellow 252 240 150|Yellow 250 214 53|Cheddar 247 164 36|Orange 240 100 36
Peach 250 190 150|Blush 245 215 205|Pastel Pink 248 190 205|Bubblegum 235 130 170|Hot Coral 240 106 102|Red 200 32 40
Raspberry 190 30 80|Magenta 190 40 110|Plum 110 40 100|Purple 120 60 150|Pastel Lavender 190 170 215|Pastel Blue 160 200 235
Light Blue 110 185 225|Blue 30 90 170|Dark Blue 25 50 110|Toothpaste 150 225 215|Turquoise 20 170 185|Pastel Green 160 215 170
Light Green 150 200 70|Parrot Green 30 170 90|Green 40 140 70|Dark Green 20 90 50|Sand 230 205 155|Tan 215 170 120
Light Brown 160 100 55|Rust 165 70 40|Brown 110 65 35|Dark Brown 70 40 25|Light Grey 200 200 205|Grey 140 140 145
Dark Grey 80 80 85|Black 20 20 20"""
PAL = []
for ch in RAW.replace("\n", "|").split("|"):
    p = ch.split(); PAL.append((" ".join(p[:-3]), tuple(int(x) for x in p[-3:])))
SYMBOLS = list("ABCDEFGHJKLMNPQRSTUVWXYZabdefghkmnqrt2345678#@%&*+=?")

def _lab(rgb):
    a = np.asarray(rgb, float) / 255.0
    a = np.where(a > 0.04045, ((a + 0.055) / 1.055) ** 2.4, a / 12.92)
    m = np.array([[.4124, .3576, .1805], [.2126, .7152, .0722], [.0193, .1192, .9505]])
    xyz = a @ m.T / np.array([.95047, 1, 1.08883])
    f = np.where(xyz > .008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)
PAL_LAB = _lab([c for _, c in PAL])

def make_pattern(data, width=29, colors=12, remove_bg=True, pixel_art=False):
    img = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert("RGBA")
    h = max(1, round(img.height * width / img.width))
    img = img.resize((width, h), Image.NEAREST if pixel_art else Image.LANCZOS)
    arr = np.array(img)
    empty = arr[..., 3] < 128
    rgb = arr[..., :3].copy(); rgb[empty] = 255
    if remove_bg and not empty.any():  # flood-fill from edges using corner color
        corners = np.array([rgb[0, 0], rgb[0, -1], rgb[-1, 0], rgb[-1, -1]], int)
        bg = np.median(corners, 0)
        close = np.abs(rgb.astype(int) - bg).sum(-1) < 60
        seen = np.zeros_like(close); dq = deque()
        for y in range(h):
            for x in (0, width - 1):
                if close[y, x]: dq.append((y, x)); seen[y, x] = True
        for x in range(width):
            for y in (0, h - 1):
                if close[y, x] and not seen[y, x]: dq.append((y, x)); seen[y, x] = True
        while dq:
            y, x = dq.popleft()
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < width and close[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True; dq.append((ny, nx))
        empty = seen
    q = np.array(Image.fromarray(rgb).quantize(colors=colors, method=Image.MEDIANCUT, dither=Image.NONE).convert("RGB"))
    uniq, inv = np.unique(q.reshape(-1, 3), axis=0, return_inverse=True)
    d = ((_lab(uniq)[:, None, :] - PAL_LAB[None]) ** 2).sum(-1)
    idx = d.argmin(1)[inv.reshape(-1)].reshape(h, width)
    idx[empty] = -1
    ids, counts = np.unique(idx[idx >= 0], return_counts=True)
    order = ids[np.argsort(-counts)]; cmap = dict(zip(ids.tolist(), counts.tolist()))
    legend, remap = [], {-1: -1}
    for n, i in enumerate(order.tolist()):
        remap[i] = n
        legend.append(dict(name=PAL[i][0], rgb=PAL[i][1], sym=SYMBOLS[n % len(SYMBOLS)], count=cmap[i]))
    grid = np.vectorize(remap.get)(idx)
    return grid, legend

def build_pdf(grid, legend, title="Bead Pattern", board=29, bead_mm=5.0):
    H, W = grid.shape
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=A4); c.setTitle(title)
    PW, PH = A4
    total = sum(l["count"] for l in legend)
    bw, bh = -(-W // board), -(-H // board)
    c.setFont("Helvetica-Bold", 22); c.drawString(40, PH - 60, title)
    c.setFont("Helvetica", 10)
    c.drawString(40, PH - 80, f"{W} x {H} beads  |  {total} beads total  |  {len(legend)} colors  |  "
                              f"finished size about {W*bead_mm/10:.1f} x {H*bead_mm/10:.1f} cm ({bead_mm:g} mm beads)")
    c.drawString(40, PH - 94, f"Pegboards needed: {bw*bh} ({bw} x {bh} of {board}x{board})  |  Generated offline by BeadSov")
    pal = np.array([l["rgb"] for l in legend] + [(255, 255, 255)], np.uint8)
    prev = Image.fromarray(pal[np.where(grid < 0, len(legend), grid)]).resize((W * 12, H * 12), Image.NEAREST)
    s = min((PW - 80) / prev.width, 300 / prev.height)
    c.drawImage(ImageReader(prev), 40, PH - 110 - prev.height * s, prev.width * s, prev.height * s)
    y = PH - 130 - prev.height * s

    def head(y):
        c.setFont("Helvetica-Bold", 9)
        for x, t in ((40, "Color"), (90, "Symbol"), (140, "Name"), (300, "Beads")): c.drawString(x, y, t)
        return y - 16
    y = head(y); c.setFont("Helvetica", 10)
    for l in legend:
        if y < 50: c.showPage(); y = head(PH - 50); c.setFont("Helvetica", 10)
        c.setFillColorRGB(*[v / 255 for v in l["rgb"]]); c.rect(40, y - 3, 35, 12, fill=1, stroke=1)
        c.setFillColorRGB(0, 0, 0)
        c.drawString(100, y, l["sym"]); c.drawString(140, y, l["name"]); c.drawString(300, y, str(l["count"]))
        y -= 17
    c.setFont("Helvetica", 8); c.setFillColorRGB(.4, .4, .4)
    c.drawString(40, 30, "Tip: colors are generic matches; compare with your own bead brand. Iron with baking paper on top.")
    c.showPage()
    CS = 16; left, top = (PW - board * CS) / 2, PH - 70
    for br in range(bh):
        for bc in range(bw):
            r0, c0 = br * board, bc * board
            r1, c1 = min(r0 + board, H), min(c0 + board, W)
            c.setStrokeColorRGB(.75, .75, .75); c.setLineWidth(.4)
            for r in range(r0, r1):
                for k in range(c0, c1):
                    x, yy = left + (k - c0) * CS, top - (r - r0 + 1) * CS
                    v = grid[r, k]
                    if v < 0:
                        c.setFillColorRGB(1, 1, 1); c.circle(x + CS / 2, yy + CS / 2, CS / 2 - 1.2, fill=0, stroke=1); continue
                    l = legend[v]; rgb = [t / 255 for t in l["rgb"]]
                    c.setFillColorRGB(*rgb); c.circle(x + CS / 2, yy + CS / 2, CS / 2 - 1, fill=1, stroke=1)
                    lum = .299 * rgb[0] + .587 * rgb[1] + .114 * rgb[2]
                    c.setFillColorRGB(*(0, 0, 0) if lum > .5 else (1, 1, 1)); c.setFont("Helvetica-Bold", 8)
                    c.drawCentredString(x + CS / 2, yy + CS / 2 - 2.8, l["sym"])
            c.setStrokeColorRGB(0, 0, 0); c.setLineWidth(.8); c.setFont("Helvetica", 6); c.setFillColorRGB(0, 0, 0)
            for k in range(c0, c1):
                if (k + 1) % 5 == 0 or k == c0: c.drawCentredString(left + (k - c0) * CS + CS / 2, top + 4, str(k + 1))
            for r in range(r0, r1):
                if (r + 1) % 5 == 0 or r == r0: c.drawRightString(left - 4, top - (r - r0) * CS - CS / 2 - 2, str(r + 1))
            c.setFont("Helvetica", 9)
            c.drawString(left, 30, f"Pegboard {br*bw+bc+1}/{bw*bh}  -  beads columns {c0+1}-{c1}, rows {r0+1}-{r1}")
            c.showPage()
    c.save(); return buf.getvalue()
