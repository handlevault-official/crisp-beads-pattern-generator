import io, os
from flask import Flask, request, send_file, render_template_string, abort
from bead import make_pattern, build_pdf

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
PAGE = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>BeadSov</title>
<style>:root{color-scheme:light dark}body{font:16px system-ui;max-width:520px;margin:40px auto;padding:0 16px}
label{display:block;margin:14px 0 4px;font-weight:600}input,select,button{width:100%;padding:10px;font-size:16px;box-sizing:border-box}
.c{display:flex;gap:8px;align-items:center;font-weight:600;margin-top:12px}.c input{width:auto}button{margin-top:20px;cursor:pointer;font-weight:700}small{opacity:.7}</style>
<h1>🟣 BeadSov</h1><p>Turn any image into a fuse-bead (Perler / Hama / Artkal style) pattern PDF.<br>
<small>Private by design: runs on your own server, no third-party APIs, nothing stored.</small></p>
<form method=post action=/generate enctype=multipart/form-data>
<label>Image</label><input type=file name=image accept="image/*" required>
<label>Title</label><input name=title value="My Bead Pattern" maxlength=60>
<label>Width in beads (10-87)</label><input type=number name=width value=29 min=10 max=87>
<label>Max colors (2-30)</label><input type=number name=colors value=10 min=2 max=30>
<label>Bead size</label><select name=bead><option value=5 selected>5 mm (Perler / Hama Midi)<option value=2.6>2.6 mm (Mini)</select>
<div class=c><input type=checkbox name=remove_bg checked id=a><label for=a style=margin:0>Remove plain background</label></div>
<div class=c><input type=checkbox name=pixel_art id=b><label for=b style=margin:0>Pixel-art mode (keeps hard edges)</label></div>
<button>Generate PDF</button></form>"""

@app.get("/")
def home(): return render_template_string(PAGE)

@app.post("/generate")
def generate():
    f = request.files.get("image")
    if not f: abort(400, "No image uploaded")
    try:
        w = min(87, max(10, int(request.form.get("width", 29)))); n = min(30, max(2, int(request.form.get("colors", 10))))
        mm = float(request.form.get("bead", 5)); title = (request.form.get("title") or "Bead Pattern")[:60]
        grid, legend = make_pattern(f.read(), w, n, "remove_bg" in request.form, "pixel_art" in request.form)
        if not legend: abort(400, "Nothing left after background removal; untick it and retry")
        pdf = build_pdf(grid, legend, title, 29, mm)
    except Exception as e:
        if hasattr(e, "code"): raise
        abort(400, f"Could not process image: {e}")
    return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True, download_name="bead-pattern.pdf")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
